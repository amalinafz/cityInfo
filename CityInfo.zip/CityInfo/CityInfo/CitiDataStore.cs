﻿using System;
using System.Collections.Generic;
using CityInfo.API.Models;

namespace CityInfo.API
{
    public class CitiesDataStore
    {
        public static CitiesDataStore Current { get; } = new CitiesDataStore();

        public List<CityDto> Cities { get; set; }

        public CitiesDataStore()
        {
            // init dummy data
            Cities = new List<CityDto>()
            {
                new CityDto()
                {
                     Id = 1,
                     Name = "Kuala Lumpur",
                     Description = "The heart of Malaysia.",
                     PointsOfInterest = new List<PointOfInterestDto>()
                     {
                         new PointOfInterestDto() {
                             Id = 1,
                             Name = "KLCC",
                             Description = "PETRONAS Twin Tower" },
                          new PointOfInterestDto() {
                             Id = 2,
                             Name = "Kampung Baru",
                             Description = "Food heaven" },
                     }
                },
                new CityDto()
                {
                    Id = 2,
                    Name = "Putrajaya",
                    Description = "Garden city",
                    PointsOfInterest = new List<PointOfInterestDto>()
                     {
                         new PointOfInterestDto() {
                             Id = 3,
                             Name = "Dataran Wawasan",
                             Description = "Breathtaking scenery" },
                          new PointOfInterestDto() {
                             Id = 4,
                             Name = "PCP",
                             Description = "For wall climbing enthusiasm" },
                     }
                },
                new CityDto()
                {
                    Id= 3,
                    Name = "Ipoh",
                    Description = "Heritage first colonised city",
                    PointsOfInterest = new List<PointOfInterestDto>()
                     {
                         new PointOfInterestDto() {
                             Id = 5,
                             Name = "Canning Dim sum",
                             Description = "Scrumptious Dim sum" },
                          new PointOfInterestDto() {
                             Id = 6,
                             Name = "Funny Mountain",
                             Description = "The best Soya Bean and Tau Fu Fah" },
                     }
                }
            };
        }

    }
}
